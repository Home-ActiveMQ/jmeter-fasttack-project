# Running Apache ActiveMQ and Red Hat hawtio in Standalone Mode
Integrating Red Hat hawtio in a standalone Apache ActiveMQ environment.

A tutorial how I did it is available here:
http://www.bennet-schulz.com/2016/07/apache-activemq-and-hawtio.html
