### Git

Provides the HTML5 front end to the back end git repository used to store configuration and files in plugins such as dashboard and wiki. 
