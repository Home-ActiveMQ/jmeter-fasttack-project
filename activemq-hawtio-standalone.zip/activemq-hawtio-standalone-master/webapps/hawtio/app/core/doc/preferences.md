### Preferences

The preferences page is used to configure {{branding.appName}} and the plugins.

The Preferences is accessible by clicking the user icon (<i class='icon-user'></i>) in the main navigation bar,
and then clicking the Preferences icon (<i class='icon-cogs'></i>).
