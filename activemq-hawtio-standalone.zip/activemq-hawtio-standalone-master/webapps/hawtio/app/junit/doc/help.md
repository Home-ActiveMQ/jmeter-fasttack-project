### JUnit

The [JUnit](#/junit/tests/) plugin in [hawtio](http://hawt.io "hawtio") offers functionality for viewing/running JUnit test cases.

##### Other Functionality #####

The [JUnit](#/junit/) can be used together with the [Test Maven Plugin](http://hawt.io/maven/) which can be used to startup
the hawtio console of a given Maven project, with unit test classes included in the classpath, allowing the [JUnit](#/junit/)
to be used to start the tests, while using the rest of the functionality of hawtio to inspect live data while the test runs.
