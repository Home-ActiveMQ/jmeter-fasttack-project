### Apm

This module supports visualisations of the APM agent in [fabric8](http://fabric8.io/)
