The **Fabric** plugin contains views and directives that interact and manage [fabric8](http://fabric8.io).

## Fabric widgets
<div ng-include="'app/fabric/html/test.html'"></div>
