## Camin plugin

This plugin is used to render Gantt sequence diagrams of Camel routes.
