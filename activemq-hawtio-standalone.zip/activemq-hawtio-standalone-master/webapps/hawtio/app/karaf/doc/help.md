### Karaf

This plugin supports the [Apache Karaf](http://karaf.apache.org/) container