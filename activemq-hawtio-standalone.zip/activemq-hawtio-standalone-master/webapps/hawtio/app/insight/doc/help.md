### Insight

This plugin provides a number of views for provising insight into a Fuse Fabric using [ElasticSearch](http://www.elasticsearch.org/) to query data for logs, metrics or historic Camel messages.