### Dozer plugin

The Dozer plugin adds editing support for the [Dozer data mapping library](http://dozer.sourceforge.net/) which can be used with [Apache Camel](http://camel.apache.org/)